import React, { useEffect, useState } from 'react';
import { MessageCircle, ArrowRight, CheckCircle, Check, Package, Ship } from 'lucide-react';
import { siteConfig } from '../config/siteConfig';
import { WORLD_DOTS_PATH } from '../config/worldDots';
import './Hero.css';

/* ---------------------------------------------------------------------------
 *  ROUTE MAP DATA
 *  Equirectangular projection: 2 SVG units per degree.
 *  x = (lon + 180) * 2      y = (80 - lat) * 2
 *  Coordinates are [longitude, latitude].
 *  The land dots come from ../config/worldDots (generated from Natural Earth).
 *  Desktop shows the whole map (lon -170..155, lat 72..-56).
 *  Phones zoom automatically onto the origin + destinations (see MOBILE_VIEWBOX).
 * ------------------------------------------------------------------------- */
type LonLat = [number, number];

const project = ([lon, lat]: LonLat) => ({ x: (lon + 180) * 2, y: (80 - lat) * 2 });

// TODO: set the real shipping origin and the export destinations you serve.
const ORIGIN = { name: 'Ontario', coord: [-85, 50] as LonLat };
const DESTINATIONS: { name: string; coord: LonLat }[] = [
  { name: 'Douala', coord: [9.7, 4.05] },
  { name: 'Rotterdam', coord: [4.5, 51.9] },
  { name: 'Lagos', coord: [3.4, 6.5] },
  { name: 'Mombasa', coord: [39.7, -4] },
  { name: 'Dubai', coord: [55.3, 25.3] },
];

const origin = project(ORIGIN.coord);

const ROUTES = DESTINATIONS.map((dest, i) => {
  const to = project(dest.coord);
  const dist = Math.hypot(to.x - origin.x, to.y - origin.y);
  const cx = (origin.x + to.x) / 2;
  const cy = (origin.y + to.y) / 2 - dist * 0.22; // arc bows upward
  const delay = i * 250; // ms
  const draw = Math.round(1400 + dist * 3.5); // ms, longer routes draw slower
  return {
    name: dest.name,
    d: `M${origin.x} ${origin.y}Q${cx} ${cy} ${to.x} ${to.y}`,
    to,
    cx,
    cy,
    delay,
    draw,
    arrive: delay + draw,
  };
});

/* ---------------------------------------------------------------------------
 *  VIEWBOXES
 *  The phone view is computed from the origin, the destinations and the top of
 *  every arc, so changing ORIGIN / DESTINATIONS never pushes a point off-screen.
 * ------------------------------------------------------------------------- */
const DESKTOP_VIEWBOX = '20 16 650 256';

const MOBILE_VIEW = (() => {
  const xs: number[] = [origin.x];
  const ys: number[] = [origin.y];
  ROUTES.forEach((r) => {
    for (let t = 0; t <= 1; t += 0.1) {
      const u = 1 - t;
      xs.push(u * u * origin.x + 2 * u * t * r.cx + t * t * r.to.x);
      ys.push(u * u * origin.y + 2 * u * t * r.cy + t * t * r.to.y);
    }
  });
  // Tight padding: the map starts right where the content starts, no empty band
  const padX = 26;
  const padTop = 18;
  const padBottom = 14;
  const minX = Math.min(...xs) - padX;
  const maxX = Math.max(...xs) + padX;
  const minY = Math.min(...ys) - padTop;
  const maxY = Math.max(...ys) + padBottom;
  const w = maxX - minX;
  const h = maxY - minY;
  return {
    box: `${minX.toFixed(1)} ${minY.toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)}`,
    aspect: w / h, // width / height of the visible map
    originY: (origin.y - minY) / h, // 0 = top of the map, 1 = bottom
  };
})();

const MOBILE_QUERY = '(max-width: 768px)';

const useIsMobile = () => {
  const [isMobile, setIsMobile] = useState(
    () => typeof window !== 'undefined' && typeof window.matchMedia === 'function' && window.matchMedia(MOBILE_QUERY).matches
  );

  useEffect(() => {
    if (typeof window.matchMedia !== 'function') return;
    const mq = window.matchMedia(MOBILE_QUERY);
    const onChange = () => setIsMobile(mq.matches);
    onChange();
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  return isMobile;
};

/* ---------------------------------------------------------------------------
 *  ANIMATION CYCLE
 *  0 Loaded -> 1 In transit (routes draw) -> 2 Delivered -> 3 fade, repeat
 * ------------------------------------------------------------------------- */
const PHASE_MS = [2000, 4200, 3400, 900];

const STEPS = [
  { key: 'loaded', title: 'Loaded', detail: 'Cargo secured at origin', Icon: Package },
  { key: 'transit', title: 'In transit', detail: 'At sea…', Icon: Ship },
  { key: 'delivered', title: 'Delivered', detail: 'Arrived at destination', Icon: CheckCircle },
];

const prefersReducedMotion = () =>
  typeof window !== 'undefined' &&
  typeof window.matchMedia === 'function' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const Hero: React.FC = () => {
  const [reduceMotion] = useState(prefersReducedMotion);
  // With reduced motion we show the finished state and never animate.
  const [phase, setPhase] = useState(reduceMotion ? 2 : 0);
  const isMobile = useIsMobile();

  useEffect(() => {
    if (reduceMotion) return;
    const timer = setTimeout(() => setPhase((p) => (p + 1) % PHASE_MS.length), PHASE_MS[phase]);
    return () => clearTimeout(timer);
  }, [phase, reduceMotion]);

  const openWhatsApp = () => {
    const url = `https://wa.me/${siteConfig.contact.whatsappNumber}?text=${encodeURIComponent(siteConfig.contact.whatsappMessage)}`;
    window.open(url, '_blank');
  };

  const scrollToServices = () => {
    const element = document.getElementById('services');
    if (element) {
      const headerHeight = 77; // matches .navbar height in Header.css
      window.scrollTo({ top: element.offsetTop - headerHeight, behavior: 'smooth' });
    }
  };

  const { hero, business } = siteConfig;

  const mapClass = [
    'route-map',
    phase >= 1 ? 'is-drawn' : '',
    phase === 3 ? 'is-fading' : '',
    reduceMotion ? 'is-static' : '',
  ]
    .filter(Boolean)
    .join(' ');

  // Markers are drawn a bit larger on phones, where the map is scaled down
  const k = isMobile ? 1.5 : 1;

  // Lets the CSS size the phone map from the screen width and start the text
  // just under the origin dot, so nothing depends on hand-tuned offsets.
  const heroVars = {
    '--map-aspect': MOBILE_VIEW.aspect.toFixed(3),
    '--origin-y': MOBILE_VIEW.originY.toFixed(3),
  } as React.CSSProperties;

  return (
    <section id="accueil" className="hero" style={heroVars} aria-label={`${business.name} - ${business.tagline}`}>
      {/* Decorative animated map */}
      <div className="hero-map" aria-hidden="true">
        <svg
          className={mapClass}
          viewBox={isMobile ? MOBILE_VIEW.box : DESKTOP_VIEWBOX}
          preserveAspectRatio="xMidYMid meet"
          focusable="false"
        >
          <path className="map-dots" d={WORLD_DOTS_PATH} />

          <g className="map-routes">
            {ROUTES.map((r) => {
              const timing = {
                '--delay': `${r.delay}ms`,
                '--draw': `${r.draw}ms`,
                '--arrive': `${r.arrive}ms`,
              } as React.CSSProperties;
              return (
                <g key={r.name} style={timing}>
                  <path className="route-ghost" d={r.d} />
                  <path className="route-trail" d={r.d} pathLength={1} />
                  <path className="route-head" d={r.d} pathLength={1} />
                  <circle className="dest-ring" cx={r.to.x} cy={r.to.y} r={2.2 * k} />
                  <circle className="dest-core" cx={r.to.x} cy={r.to.y} r={1.7 * k} />
                </g>
              );
            })}
          </g>

          <circle className="origin-ring" cx={origin.x} cy={origin.y} r={2.6 * k} />
          <circle className="origin-core" cx={origin.x} cy={origin.y} r={1.9 * k} />
        </svg>
      </div>
      <div className="hero-scrim" aria-hidden="true" />

      <div className="hero-inner">
        <div className="hero-copy">
          <h1 className="hero-title">
            <span className="title-company">{hero.titleLine1}</span>
            <span className="title-white">{hero.titleLine2}</span>
            <span className="title-accent">{hero.titleLine3}</span>
          </h1>

          <p className="hero-description">
            {hero.description.split(hero.descriptionHighlight).map((part, idx, arr) => (
              <React.Fragment key={idx}>
                {part}
                {idx < arr.length - 1 && <span className="location-highlight">{hero.descriptionHighlight}</span>}
              </React.Fragment>
            ))}
          </p>

          <div className="hero-buttons">
            <button onClick={openWhatsApp} className="btn btn-whatsapp" aria-label={hero.primaryCta}>
              <span>{hero.primaryCta}</span>
              <ArrowRight className="btn-arrow" aria-hidden="true" />
              <div className="btn-shine"></div>
            </button>
            <button onClick={scrollToServices} className="btn btn-service" aria-label={hero.secondaryCta}>
              <span>{hero.secondaryCta}</span>
              <ArrowRight className="btn-arrow" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Floating shipment-tracking card (decorative sample) */}
        <aside className="track-card" aria-hidden="true">
          <div className="track-head">
            <span className="track-title">Shipment tracking</span>
            <span className="track-tag">Example</span>
          </div>
          <ol className="track-steps">
            {STEPS.map(({ key, title, detail, Icon }, i) => {
              const state = phase > i ? 'done' : phase === i ? 'active' : 'idle';
              return (
                <li key={key} className={`track-step is-${state}`}>
                  <span className="track-marker">
                    {state === 'done' ? <Check size={14} strokeWidth={3} /> : <Icon size={14} />}
                  </span>
                  <span className="track-text">
                    <span className="track-step-title">{title}</span>
                    <span className="track-step-detail">{detail}</span>
                  </span>
                </li>
              );
            })}
          </ol>
        </aside>
      </div>
    </section>
  );
};

export default Hero;